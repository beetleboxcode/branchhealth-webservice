<?php 

if (version_compare(PHP_VERSION, '5.3.1', '<')) {
	die('Hosting anda mesti menggunakan PHP 5.3.1 atau lebih tinggi untuk menjalankan aplikasi ini!');
}

ob_start();
error_reporting(E_ALL);
define('_BDZ', 1);
define('BDZ_BASE',__DIR__);

session_start();

require_once 'config.php';
require_once 'path.php';
require_once 'function.php';

define('BDZ_URL_IMG',BDZ_URL_ROOT.'/img');
define('BDZ_PATH_IMG',BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'images');

$dataVar = sizeof($varURL);
if($dataVar > 0) {
	switch($varURL[0]) {
		case 'checklogin':
		$fileDisplay = 'getloginact';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'showmarket':
		$fileDisplay = 'getmarketact';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'showitemmarket':
		$fileDisplay = 'getitembymarket';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'showaddressuser':
		$fileDisplay = 'getaddressbyuser';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'gettranscbymarket':
		$fileDisplay = 'gettransactionlistbymarket';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'getdetbytransc':
		$fileDisplay = 'gettransactiondetaillistbytransc';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'getheaderbyuser':
		$fileDisplay = 'gettransactionlistbyuser';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'addtrans':
		$fileDisplay = 'inserttransaction';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'insertheadertransc':
		$fileDisplay = 'inserttransactionheader';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'insertitemtransc':
		$fileDisplay = 'inserttransactionitem';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'printsubtotal':
		$fileDisplay = 'printoutsubtotal';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		case 'updatenotifyuser':
		$fileDisplay = 'updatenotifybyuserandtransc';
		require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		break;

		default:
			if (isset($_SESSION['xmart_user_admin'])) {
				$fileDisplay = 'dashboardact';
				require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
			}else{
				$fileDisplay = 'loginact';
				require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
			}
		break;
	}
}else{
	$fileDisplay = 'loginact';
	require_once BDZ_PATH_ROOT.DIRECTORY_SEPARATOR.'module'.DIRECTORY_SEPARATOR.$fileDisplay.'.php';
		
}

ob_end_flush();
?>