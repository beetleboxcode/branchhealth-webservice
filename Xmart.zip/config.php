<?php 
defined('_BDZ') or die;
$dbhost = 'mysql.idhostinger.com';
$dbuser = 'u353658987_admin';
$dbpass = 'Testing123456 ';
$dbname = 'u353658987_bhc';
/*
$dbhost = "mysql.idhostinger.com";
$dbuser = 'u509243393_xmart';
$dbpass = 'ttt111lll111sss';
$dbname = 'u509243393_xmart';
*/ ?>