<?php 
defined('_BDZ') or die;

if (isset($_POST['username']) && isset($_POST['password'])  ) {
	$username=$_POST['username'];
	$password=$_POST['password'];

	$querylogin="	SELECT a.*,
							b.market_name,
							b.market_street,
							b.market_phone,
							b.market_no,
							b.market_rt,
							b.market_rw,
							b.market_longitude,
							b.market_latitude
					FROM xmart_user_admin a 
						LEFT JOIN xmart_market b on a.market_id = b.market_id 
					WHERE a.user_admin_username ='$username' and a.user_admin_password = '$password'";
	$dataLogin = resultData($querylogin);
	if (!empty($dataLogin)) {
		$_SESSION['xmart_user_admin'] = $username;		
		$_SESSION['market_id'] = $dataLogin['market_id'];		
		$_SESSION['market_name'] = $dataLogin['market_name'];		
		$_SESSION['market_street'] = $dataLogin['market_street'];		
		$_SESSION['market_phone'] = $dataLogin['market_phone'];		
		$_SESSION['market_no'] = $dataLogin['market_no'];		
		$_SESSION['market_rt'] = $dataLogin['market_rt'];		
		$_SESSION['market_rw'] = $dataLogin['market_rw'];		
		$_SESSION['market_longitude'] = $dataLogin['market_longitude'];		
		$_SESSION['market_latitude'] = $dataLogin['market_latitude'];		
		header("location:".BDZ_URL_ROOT.'/dashboardact');
	}
}
?>
 <!DOCTYPE html>
 <head>
 	<title>Login Page</title>
 	<link rel="stylesheet" type="text/css" href="style.css">
 		
 </head>
 <body>
 	<div class="login-wrapper">
 		<div class="login-container">
 			<form action="#" method="POST">
	 			<div class="login-box">
	 				<div class="login-control">
	 					<div class="login-label">Username</div>
	 					<div class="login-input"><input type="text" name="username"></div>
	 				</div>
	 				<div class="login-control">
	 					<div class="login-label">Password</div>
	 					<div class="login-input"><input type="password" name="password"></div>
	 				</div>
	 				<div class="login-control">
	 					<input class="form-right" type="submit" name="submit">
	 				</div>
	 			</div>
 			</form>
 		</div>
 	</div>
 </body>
 </html>