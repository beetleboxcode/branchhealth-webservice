<?php 
defined('_BDZ') or die;
	if (isset($_REQUEST['marketid'])) {
		$marketId = $_REQUEST['marketid'];

		$response = array();
		$response["status"] = "fail";
		$response["item"] = array();

		$queryItem = "SELECT  a.market_id,
								a.market_item_id,
								b.item_name,
								b.item_weight,
								b.item_barcode,
								(a.market_item_quantity-(case when c.count  is null then 0 else c.count  end))market_item_quantity,
								a.market_item_price,
								d.type_id,
								d.type_name
						FROM 	xmart_market_item a 
								left join xmart_item b on a.item_id = b.item_id 
								LEFT JOIN (
									SELECT sum(b.sales_detail_count) count,b.item_id
									FROM xmart_sales a 
										LEFT JOIN xmart_sales_detail b on a.sales_id = b.sales_id
									WHERE a.market_id = $marketId
									GROUP BY b.item_id
								) c on a.market_item_id = c.item_id 
								LEFT JOIN xmart_item_type d on b.type_id = d.type_id
						WHERE 	a.market_id = $marketId";
		$dataItem = queryData($queryItem);
		while ($row = mysqli_fetch_array($dataItem)) {
			$item = array(
					'market_id' 	=> 			$row["market_id"],
					'market_item_id'=> 			$row["market_item_id"],
					'name' 			=> 			$row["item_name"],
					'weight' 		=> 			$row["item_weight"],
					'barcode' 		=> 			$row["item_barcode"],
					'quantity' 		=> 			$row["market_item_quantity"],
					'price' 		=> 			$row["market_item_price"],
					'type_id' 		=> 			$row["type_id"],
					'type_name'		=> 			$row["type_name"]
					);
			array_push($response['item'], $item);

			$response["status"] = "success";
		}
	}else{
			$item = array(
				'market_id' 	=> 			'',
				'market_item_id'=> 			'',
				'name' 			=> 			'',
				'weight' 		=> 			'',
				'barcode' 		=> 			'',
				'quantity' 		=> 			'',
				'price' 		=> 			'',
				'type_id' 		=> 			'',
				'type_name'		=> 			''
				);
	array_push($response["item"], $item);
			
	}
	

echo json_encode($response);
 ?>