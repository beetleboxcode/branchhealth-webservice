<!-- <?php 
defined('_BDZ') or die;
	$response = array();
	$response['status']="fail";
	$response['market']=array();
	$queryMarket = "SELECT * FROM xmart_market ORDER BY market_name";
	$dataMarket = queryData($queryMarket);
	while ($row = mysqli_fetch_array($dataMarket)) {
		$market = array(
				'id' 		=> 			$row["market_id"],
				'name' 		=> 			$row["market_name"],
				'phone' 	=> 			$row["market_phone"],
				'no' 		=> 			$row["market_no"],
				'street' 	=> 			$row["market_street"],
				'rt' 		=> 			$row["market_rt"],
				'rw' 		=> 			$row["market_rw"],
				'longitude' => 			$row["market_longitude"],
				'latitude' 	=> 			$row["market_latitude"]
				);
		array_push($response['market'], $market);
		$response['status']="success";
	}

echo json_encode($response);
 ?> -->

 <?php 
defined('_BDZ') or die;
	$response = array();
	$response['status']="fail";
	$response['market']=array();
	$queryMarket = "SELECT * FROM city ORDER BY city";
	$dataMarket = queryData($queryMarket);
	while ($row = mysqli_fetch_array($dataMarket)) {
		$city = array(
				'id' 			=> 			$row["id"],
				'city' 			=> 			$row["city"],
				'updated_date' 	=> 			$row["updated_date"]
				);
		array_push($response['city'], $city);
		$response['status']="success";
	}

echo json_encode($response);
 ?>