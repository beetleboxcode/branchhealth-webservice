<?php 
defined('_BDZ') or die;

	$response = array();
	$response['status']="fail";

	if (isset($_REQUEST['transid']) && isset($_REQUEST['userid'])) {
		
		$transid = $_REQUEST['transid'];
		$userid = $_REQUEST['userid'];

		//check apakah yang execute orang yang pesan atau bukan, perubahan status harus dari orang yang mesan
		$queryCheckUserid = "SELECT user_id from xmart_sales where sales_id=$transid";
		$executeCheck = resultData($queryCheckUserid);
		$dataUserid = $executeCheck[0];
		if ($dataUserid == $userid) {

			//update sales status
			$querySales = "UPDATE xmart_sales SET sales_status = 3, sales_date_complete = now() where sales_id = $transid";
			$executeSales = queryData($querySales);

			//update notify
			$queryNotify = "UPDATE xmart_notify SET notify_status = 0, sales_status = 3 where sales_id = $transid";
			$executeNotify = queryData($queryNotify);

			//insert history
			$querySalesHistory = "INSERT INTO xmart_sales_history(sales_id,sales_status,sales_history_date) VALUES ($transid,3,now())";
			$executeSalesHistory = queryData($querySalesHistory);

			$response['status']="success";
		}
		
	}

	echo json_encode($response);
 ?>