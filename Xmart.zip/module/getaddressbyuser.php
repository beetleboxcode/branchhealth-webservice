<?php 
	

	if (isset($_REQUEST['userid'])) {
		$userId = $_REQUEST['userid'];

		$response = array();
		$response["status"] = "fail";
		$response["address"] = array();

		$queryItem = "	SELECT 
							user_id,
							address_street,
							address_no,
							address_rt,
							address_rw,
							address_additional,
							address_phone,
							address_longitude,
							address_latitude 
						FROM `xmart_address` 
						WHERE user_id = $userId";
		$dataAddress = queryData($queryItem);
		while ($row = mysqli_fetch_array($dataAddress)) {
			$address = array(
					'user_id' 	=> 			$row["user_id"],
					'street' 	=> 			$row["address_street"],
					'no' 		=> 			$row["address_no"],
					'rt' 		=> 			$row["address_rt"],
					'rw' 		=> 			$row["address_rw"],
					'additional'=> 			$row["address_additional"],
					'phone' 	=> 			$row["address_phone"],
					'longitude' => 			$row["address_longitude"],
					'latitude' 	=> 			$row["address_latitude"]
					);
			array_push($response['address'], $address);

			$response["status"] = "success";
		}
	}else{
			$address = array(
				'user_id' 	=> 			"",
				'street' 	=> 			"",
				'no' 		=> 			"",
				'rt' 		=> 			"",
				'rw' 		=> 			"",
				'additional'=> 			"",
				'phone' 	=> 			"",
				'longitude' => 			"",
				'latitude' 	=> 			""
				);
	array_push($response["address"], $address);
			
	}

	echo json_encode($response);

 ?>