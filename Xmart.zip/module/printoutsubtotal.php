	<?php 
defined('_BDZ') or die;
	if (isset($_REQUEST['transcid'])) {

		$transcid = $_REQUEST['transcid'];

		//check apa benar ini transaksi milik toko ini
		$queryCheckMarket = "SELECT market_id FROM xmart_sales WHere sales_id =". $transcid;
		$executeCheck = resultData($queryCheckMarket);
		$marketID = $executeCheck[0];
		if ($marketID != $_SESSION['market_id']) {
			header("location:".BDZ_URL_ROOT);
		}

		$queryItem = "SELECT 
					 		a.item_id,
					 		a.sales_detail_count,
					 		c.market_item_price,
					 		d.item_name
					 from xmart_sales_detail a
					 	LEFT JOIN xmart_sales b on a.sales_id = b.sales_id
					 	LEFT JOIN xmart_market_item c on a.item_id = c.market_item_id and b.market_id = c.market_id
					 	LEFT JOIN xmart_item d on c.item_id = d.item_id
					 where b.sales_id =".$transcid ."
					 order by d.item_name";
		$dataItem = queryData($queryItem);

		$queryPerson = "SELECT a.user_id,
								c.user_username,
								b.address_id,
								b.address_street,
								b.address_no,
								b.address_rt,
								b.address_rw,
								b.address_additional,
								b.address_phone,
								b.address_longitude,
								b.address_latitude,
								d.market_name,
								d.market_phone, 
								d.market_street,
								d.market_no,
								d.market_rt,
								d.market_rw,
								a.sales_date
						FROM xmart_sales a 
							LEFT JOIN xmart_address b on a.user_id = b.user_id
							LEFT JOIN xmart_user c on a.user_id = c.user_id
							LEFT JOIN xmart_market d  on a.market_id = d.market_id
						WHERE a.sales_id=".$transcid;
		$dataPerson = resultData($queryPerson);

	}else{
		header("location:".BDZ_URL_ROOT);
	}
	$totalSales=0;
 ?>
<html>
<head>
	<title>Print Out</title>
</head>
<link rel="stylesheet" type="text/css" href="print-style.css">
<body>
	<div class="print-wrapper">
		<div class="print-container">
			<div class="line"></div>
			<div class="print-header">
				<div class="print-header-title"><?php echo $dataPerson['market_name'] ?></div>
				<div class="print-header-address"><?php echo $dataPerson['market_street'].' No:'.$dataPerson['market_no'] ?></div>
				<div class="print-header-date"><?php echo $dataPerson['sales_date'] ?> </div>
			</div>
			
			<div class="line"></div>
			
			<div class="print-sub-body">
					<div class="print-sub-body-name"><?php echo $dataPerson['user_username'] ?></div>
					<div class="print-sub-body-address"><?php echo  $dataPerson['address_street'].' No:'.$dataPerson['address_no'] ?></div>
					<div class="print-sub-body-phone">Telp. <?php echo $dataPerson['address_phone'] ?></div>
			</div>
			
			<div class="line"></div>

			<div class="print-body-control">
				<div class="print-body-label"><b>Item Name</b></div>
				<div class="print-body-qty"><b> Qty</b></div>
				<div class="print-body-price"><b>Sub total</b></div>
			</div>
			<div class="print-body-control">
				<div class="print-body-label">---------------------------------------------------</div>
				<div class="print-body-qty">-------</div>
				<div class="print-body-price">--------------</div>
			</div>

			<div class="print-body">
				<?php while ( $row = mysqli_fetch_array($dataItem)) { ?>
					<div class="print-body-control">
						<div class="print-body-label"> <?php echo $row['item_name']; ?></div>
						<div class="print-body-qty"> <?php echo number_format($row['sales_detail_count']); ?></div>
						<div class="print-body-price"><?php echo number_format($row['sales_detail_count'] * $row['market_item_price']) ?></div>
						<?php  $totalSales = $totalSales + ($row['sales_detail_count'] * $row['market_item_price']) ?>
					</div>
				<?php } ?>
			</div>

			<div class="print-body-control">
					<div class="print-body-label">---------------------------------------------------</div>
					<div class="print-body-qty">-------</div>
					<div class="print-body-price">--------------</div>
				</div>
			<div class="print-body-control">
					<div class="print-body-label"><b>Total</b></div>
					<div class="print-body-qty">:</div>
					<div class="print-body-price"><?php echo number_format($totalSales); ?></div>
				</div>
			<div class="line"></div>
			<div class="print-footer">
				<small>Xmart 2015</small>
			</div>
			<div class="line"></div>

		</div>
	</div>
</body>
</html>

<script type="text/javascript">window.print();</script>