<?php 

defined('_BDZ') or die;

//insert market item
if (isset($_POST['submitMarketItem'])) {
	$marketID = $_POST["marketid"];
	$marketItemID = $_POST["marketItemID"];
	$marketItem = $_POST['marketItem'];
	$marketQuantity =$_POST['marketQuantity'];
	$marketPrice =$_POST['marketPrice'];
	if ($marketItemID == "") {
		$query = "INSERT INTO xmart_market_item(item_id, market_id, market_item_quantity, market_item_price) 
					VALUES ('$marketItem', '$marketID', '$marketQuantity', '$marketPrice')";
	}else{
		$query = "UPDATE xmart_market_item set item_id = $marketItem, market_item_quantity = $marketQuantity, market_item_price = $marketPrice
					WHERE market_item_id = $marketItemID";
	}
	$execute = queryData($query);
}

//insert master item
if (isset($_POST['submitMaster']) ) {
 	$id=$_POST['id'];
 	$name=$_POST['name'];
 	$type=$_POST['type'];
 	$weight=$_POST['weight'];
 	$price=$_POST['price'];
 	$barcode=$_POST['barcode'];
 	if ($id == "") {
	 	$query = "INSERT INTO xmart_item(item_name,type_id,item_weight,item_price,item_barcode) 
	 						VALUES ('$name','$type','$weight','$price','$barcode')";
 	}else{
	 	$query = "UPDATE xmart_item 
	 				SET item_name = '$name',
	 					type_id = '$type',
	 					item_weight = '$weight',
	 					item_price = '$price',
	 					item_barcode = '$barcode'
	 				WHERE item_id = $id";
 	}
 	$execute = queryData($query);
} 

//change status to complate
if (isset($_POST['complete'])) {
	$id = $_POST['id'];
	//update status sales
	$queryUpdate = "Update xmart_sales set sales_status = 2 where sales_id = $id";
	$exec = queryData($queryUpdate);

	//insert notification
	$querySalesNotification = "INSERT INTO xmart_notify(sales_id,sales_status) VALUES ($id,2)";
	$executeSalesNotification = queryData($querySalesNotification);

	//insert history
	$querySalesHistory = "INSERT INTO xmart_sales_history(sales_id,sales_status,sales_history_date) VALUES ($id,2,now())";
	$executeSalesHistory = queryData($querySalesHistory);

}

$query="SELECT type_id, type_name FROM xmart_item_type";
$dataType = queryData($query);

$query="SELECT item_id,item_name,type_id,item_weight,item_price,item_barcode FROM xmart_item";
$dataItemMaster = queryData($query);

$query="SELECT item_id,item_name,type_id,item_weight,item_price,item_barcode FROM xmart_item";
$dataDDItemMaster = queryData($query);

$marketID = $_SESSION['market_id'];
$query="SELECT a.market_item_id, 
				a.item_id, 
				a.market_id, 
				(a.market_item_quantity-(case when c.count  is null then 0 else c.count  end))market_item_quantity,
				a.market_item_price, 
				b.item_name 
		FROM xmart_market_item a 
			LEFT JOIN xmart_item b on a.item_id = b.item_id
			LEFT JOIN (
							SELECT sum(y.sales_detail_count) count,y.item_id
							FROM xmart_sales x 
								LEFT JOIN xmart_sales_detail y on x.sales_id = y.sales_id
							WHERE x.market_id = $marketID
							GROUP BY y.item_id
						) c on a.market_item_id = c.item_id 
		where a.market_id = $marketID" ;
$dataItemMarket = queryData($query);
 ?>


  <!DOCTYPE html>
  <html>
<head>
	<title>Dashboard XMarket</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta http-equiv="X-UA-Compatible" content="IE=10" />
	<script src="https://maps.googleapis.com/maps/api/js"></script>
	<script src="<?php echo BDZ_URL_ROOT.'/jquery/jquery.min.js' ?>"></script>
	<script src="<?php echo BDZ_URL_ROOT.'/jquery/jquery.number.js' ?>"></script>
	<script>

	

	$(document).ready(function(){
		$(".add-market-item").click(function(){
			$(".dashboard-add-item-wrapper-popup").fadeIn();
		});
		$(".close-add-popup").click(function(){
			$(".dashboard-add-item-wrapper-popup").fadeOut();
		});
		$(".add-master-item").click(function(){
			$(".dashboard-addmaster-item-wrapper-popup").fadeIn();
		});
		$(".close-addmaster-popup").click(function(){
			$(".dashboard-addmaster-item-wrapper-popup").fadeOut();
		});

		$(".close-popup").click(function(){
			$(".dashboard-item-wrapper-popup").fadeOut();
		});
		$(document).on('click','.detail-btn',function(e){
			index = $(".detail-btn").index(this);
			link = "<?php echo BDZ_URL_ROOT.'/'.'getdetbytransc?transcid='?>" + $('.id-transaction').eq(index).text();
			$(".dashboard-item-wrapper-popup").fadeIn();
			$.ajax({
	                type: "GET",
	                dataType: 'json',
	                url: link,
	                success: function(response){
	                	if (response.status == 'success') {
	                		$(".item-detail-sales").remove();
	                		no = 1;
	                		total = 0;
	                		$.each(response.item,function(key,item){
	                			div1 = "<tr class='item-detail-sales'>"+
	                					"<td>"+ no +"</td>"+
	                					"<td>"+ item.name +"</td>"+
	                					"<td>"+ item.count +"</td>"+
	                					"<td>"+ $.number(item.market_price) +"</td>"+
	                					"<td>"+ $.number(Number(item.market_price*item.count)) +"</td>"+
	                					"</tr>";
	                			$(".table-detail-sales").append(div1);
	                			total += Number(item.market_price*item.count);
	                			no++;
	                		});
	                		//$(".grandtotal").text("Total = "+ total); 

	                		$.each(response.person,function(key,person){
	                			$("#detail-id").text(person.user_username);
	                			$("#detail-name").text(person.user_username);
	                			$("#detail-address").text(person.address_street);
	                			$("#detail-additional").text(person.address_additional);
	                			$("#detail-phone").text(person.address_phone);
	                			$("#detail-date").text(person.sales_date);
	                			$("#detail-total").text($.number(total));
	                		});

	                	};
	                },
	                error: function(e){
	                	console.log("error");
	                }
            }); 
		});

		setInterval(
						function(){
							link = "<?php echo BDZ_URL_ROOT.'/'.'gettranscbymarket?marketid='.$_SESSION['market_id']; ?>";
							$.ajax({
					                type: "GET",
					                dataType: 'json',
					                url: link,
					                success: function(response){
					                	if (response.status == 'success') {
					                		$(".item-sales").remove();
					                		no = 1;
					                		noCplt = 1;
					                		$.each(response.transaction,function(key,item){
					                			div1 = "<tr class='item-sales'>";

					                			if (item.status =='complete') {
					                					div1 = div1 + "<td><div class='no-item'>"+ noCplt +"</div></td>";
					                				}else{
					                					div1 = div1 + "<td><div class='no-item'>"+ no +"</div></td>";
					                				};
					                			div1 = div1 +	"<td>"+
						                							"<div class='sales-control'><div class='sales-label'>ID Transaction  </div> <div class='sales-value id-transaction'>"+ item.id + " </div></div>"+
						                							"<br><div class='sales-control'><div class='sales-label'>Date </div> <div class='sales-value'>"+ item.date + "</div></div>"+
						                							"<br><div class='sales-control'><div class='sales-label'>Date Complete</div> <div class='sales-value'>"+ item.complete + "</div></div>"+
						                							"<br><div class='sales-control'><div class='sales-label'>status </div> <div class='sales-value' style='color:orange;font-size:15px;'>"+ item.status + "</div></div>"+
						                							"<br><div class='sales-control'><div class='sales-label'>name  </div> <div class='sales-value'>"+ item.name + "</div></div>"+
						                							"<br><div class='sales-control'><div class='sales-label'>street </div> <div class='sales-value'>"+ item.street + "</div></div>"+
						                							"<br><div class='sales-control'><div class='sales-label'> additional </div> <div class='sales-value'>"+ item.additional + "</div></div>";
						                		if (item.status == 'pending') {
						                			div1 = div1 + "<br><div class='sales-control'><div class='sales-label'> change status </div> <div class='sales-value'><form action='<?php echo BDZ_URL_ROOT.'/dashboardact' ?>' method='POST'><input type='hidden' value='"+item.id+"' name='id'><input type='submit' name='complete' value='Send item'></form></div></div>";
						                		};					
					                			div2="<button class='form-right detail-btn'>Show item detail</button> <a href='<?php echo BDZ_URL_ROOT.'/printsubtotal?transcid=' ?>"+ item.id+ "' class='button form-right print-subtotal' target='_blank'>Print</a> <div class='line'></div></td> "+
					                					"</tr>";
					                			if (item.status == 'complete') {
					                				$(".table-sales-complete").append(div1+div2);
					                				noCplt++;
						                		}else{
					                				$(".table-sales").append(div1+div2);
					                				no++;
						                		};		
					                			
					                		});
					                		$("#network-status").text("Connected");
					                	};
					                },
					                error: function(e){
					                		$("#network-status").remove();
					                		$("#network-status").text("Disconected");

					                	console.log("error");
					                }
				            }); 
						}
			,3000);

		$(".edit-item-master").click(function(){
			index = $(".edit-item-master").index(this);
			$(".itemID").val( $(".id-item-master").eq(index).text() );
			$(".itemName").val( $(".name-item-master").eq(index).text() );
			$(".itemType").val( $(".type-item-master").eq(index).text() );
			$(".itemWeight").val( $(".weight-item-master").eq(index).text() );
			$(".itemPrice").val( $(".price-item-master").eq(index).text() );
			$(".itemBarcode").val( $(".barcode-item-master").eq(index).text() );
		});

		$(".edit-item-market").click(function(){
			index = $(".edit-item-market").index(this);
			$(".itemMarketID").val( $(".id-item-market").eq(index).text() );
			$(".itemMarketitem").val($(".name-item-market").eq(index).val());
			$(".itemMarketQuantity").val( $(".quantity-item-market").eq(index).text() );
			$(".itemMarketPrice").val( $(".price-item-market").eq(index).text() );

		});
	});



if (google.maps) {
	 function initialize() {
        var mapCanvas = document.getElementById('map');
        var latitude = <?php echo $_SESSION['market_latitude'] ?>;
        var longitude = <?php echo $_SESSION['market_longitude'] ?>;

      	var myLatLng = {lat:latitude , lng: longitude};
        var mapOptions = {
          center: myLatLng,
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(mapCanvas, mapOptions)
		var marker = new google.maps.Marker({
		    position: myLatLng,
		    title:"<?php echo $_SESSION['market_name'] ?>"
		});

		marker.setMap(map);
      }

      google.maps.event.addDomListener(window, 'load', initialize);
}else{

};

    </script>



</head>
<body >
	<div class="dashboard-wrapper">
		<div class="dashboard-container">
			<div class="dashboard-header-wrapper">
				<div class="dashboard-header-container">
						<img  class="logo" src="img/logo.jpg">
					<div class="dashboard-header-text">
						Dashboard XMart
					</div>

					<div class="logout-button form-right">
						<a href="logout.php">Logout</a>
					</div>

					<div class="logout-button form-right add-market-item ">
						<div class="white"><i class="fa fa-plus-circle red"></i> Add Market Item</div>
					</div>

					<div class="logout-button form-right add-master-item ">
						<div class="white"><i class="fa fa-plus-circle red"></i> Add Master Item</div>
					</div>


				</div>
				<div class="dashboard-running-text-wrapper">
					<div class="dashboard-running-text-container">
						<marquee>
							Welcome to X-mart Application, For support please call 021 - 87283xxxxx or can email  
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</marquee>
					</div>
				</div>
				<div class="dashboard-body-wrapper">

					<div class="dashboard-body-container">
						<div class="dashboard-item-wrapper-small">
							<div class="dashboard-item-container">
								<div class="dashboard-item-header">
									<div class="dashboard-item-title">
										<i class="fa fa-street-view red"></i> Market Info
									</div>
								</div>
								<div class="dashboard-left-small">
									<div class="market-detail-wrapper">
										<div class="market-detail-container">
											<div class="market-detail-location" id="map"></div>
											<div class="clearfix"></div>
											<div class="market-detail-text">
												<div class="market-detail-control">
													<div class="market-detail-label">Network Status</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" id="network-status"></div>
												</div>
												<div class="market-detail-control"></div>
												<div class="market-detail-control"></div>
												<div class="market-detail-control"></div>

												<div class="market-detail-control">
													<div class="market-detail-label">Name</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"><?php echo $_SESSION['market_name'] ?></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Address</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"><?php echo $_SESSION['market_street'].' No:' .$_SESSION['market_no'] .' Rt:'.$_SESSION['market_rt'].' Rw:'. $_SESSION['market_rw'] ;?></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Phone</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"><?php echo $_SESSION['market_phone'] ?></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>


						<div class="dashboard-item-wrapper">
							<div class="dashboard-item-container">
								<div class="dashboard-item-header">
									<div class="dashboard-item-title">
										<i class="fa fa-truck yellow"></i> Daily Sales Pending
									</div>
								</div>
								<div class="dashboard-left">
									<table class="table-sales">
										<tr class="sales-header">
											<th>No</th>
											<th>Detail Transaction</th>
										</tr>
									</table>
								</div>
							</div>
						</div>
						
						<div class="dashboard-item-wrapper">
							<div class="dashboard-item-container">
								<div class="dashboard-item-header">
									<div class="dashboard-item-title">
										<i class="fa fa-gift green"></i> Daily Sales Complete
									</div>
								</div>
								<div class="dashboard-left">
									<table class="table-sales-complete">
										<tr class="sales-header-complete">
											<th>No</th>
											<th>Detail Transaction</th>
										</tr>
									</table>
								</div>
							</div>
						</div>
						



						<div class="dashboard-item-wrapper-popup">
							<div class="dashboard-item-popup-back"></div>
							<div class="dashboard-item-container-popup">
								<div class="dashboard-item-header">
									<div class="dashboard-item-title">
										Detail Sales
										<div class="close-popup">x</div>
									</div>
								</div>
								<div class="dashboard-left dashboard-left-popup">
									<div class="dashboard-detail">
										<div class="dashboard-detail-person">
												<div class="market-detail-control">
													<div class="market-detail-label">ID Transaction</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"  id="detail-id"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Time </div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"  id="detail-date"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Promo</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"  id="detail-promo">...</div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Discount</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"  id="detail-discount">...</div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Total</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input"  id="detail-total"></div>
												</div>
												
										</div>
										<div class="dashboard-detail-person">
												<div class="market-detail-control">
													<div class="market-detail-label">Name</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" id="detail-name"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Address</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" id="detail-address"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Additional</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" id="detail-additional"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Phone</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" id="detail-phone"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Location</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" id="detail-location"><button>Go to Location</button></div>
												</div>
										</div>


										<div class="line"></div>


										<table class="table-detail-sales">
											<tr class="sales-detail-header">
												<th>No</th>
												<th>Item</th>
												<th>Qty	</th>
												<th>Price</th>
												<th>Sub total</th>
											</tr>
										</table>
										<!-- <div class="form-right grandtotal"></div> -->
									</div>
								</div>
							</div>
						</div>

 




						<div class="dashboard-add-item-wrapper-popup">
							<div class="dashboard-add-item-popup-back"></div>
							<div class="dashboard-add-item-container-popup">
								<div class="dashboard-add-item-header">
									<div class="dashboard-add-item-title">
										Add Market Item
										<div class="close-add-popup">x</div>
									</div>
								</div>
								<div class="dashboard-left dashboard-left-popup">
									<div class="dashboard-detail">
										
										<form action="<?php echo BDZ_URL_ROOT.'/dashboardact' ?>" method="POST">
											<div class="dashboard-detail-person">
												<div class="market-detail-control">
													<div class="market-detail-label">Market ID</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" >
														<input type="text" name="marketid" readonly="true" value="<?php echo $marketID ?>" class="itemMarketMarket">
														<br>
														 <small>default ID Market</small>
													</div>
													
												</div>
												
												<div class="market-detail-control">
													<div class="market-detail-label">Market Item ID</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" >
														<input type="text" name="marketItemID" class="itemMarketID">
														<br>
														 <small>kosongkan jika input baru</small>
													</div>
												</div>

												<div class="market-detail-control">
													<div class="market-detail-label">Item</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" >
														<select name="marketItem" class="itemMarketitem" >
															<?php while ( $row = mysqli_fetch_array($dataDDItemMaster)) { ?>
																<option value="<?php echo $row['item_id'] ?>"><?php echo $row['item_name'] ?></option>
															<?php } ?>
														</select>
													</div>
												</div>

											</div>
											<div class="dashboard-detail-person">
												<div class="market-detail-control">
													<div class="market-detail-label">Quantity</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" ><input type="text" name="marketQuantity" class="itemMarketQuantity"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Price</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" ><input type="text" name="marketPrice" class="itemMarketPrice"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label"></div>
													<div class="market-detail-tick"></div>
													<div class="market-detail-input" ><input class="form-right" name="submitMarketItem" type="submit"></div>
												</div>
											</div>	
										</form>
										<div class="line"></div>
										<table class="table">
											<thead>
												<tr>
													<th>ID</th>
													<th>Item</th>
													<th>Quantity</th>
													<th>Price</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody class="table-scroll">
												<?php while ($row = mysqli_fetch_array($dataItemMarket)) { ?>
												<tr>
													<td class="id-item-market"><?php echo $row['market_item_id'] ?></td>
													<td >
														<input type="hidden" class="name-item-market" value="<?php echo $row['item_id'] ?>">
														<?php echo $row['item_name'] ?></td>
													<td class="quantity-item-market"><?php echo $row['market_item_quantity'] ?></td>
													<td class="price-item-market"><?php echo $row['market_item_price'] ?></td>
													<td class=""><button class="edit-item-market">edit</button></td>
												</tr>
												<?php } ?>
											</tbody>
										</table>

									</div>
								</div>
							</div>
						</div>


						<div class="dashboard-addmaster-item-wrapper-popup">
							<div class="dashboard-addmaster-item-popup-back"></div>
							<div class="dashboard-addmaster-item-container-popup">
								<div class="dashboard-addmaster-item-header">
									<div class="dashboard-addmaster-item-title">
										Add Master Item
										<div class="close-addmaster-popup">x</div>
									</div>
								</div>
								<div class="dashboard-left dashboard-left-popup">
									<div class="dashboard-detail">
										<form action="<?php echo BDZ_URL_ROOT.'/dashboardact' ?>" method="POST">
											<div class="dashboard-detail-person">
												

												<div class="market-detail-control">
													<div class="market-detail-label">Item ID</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" >
														<input type="text" name="id" class="itemID">
														<br>
														 <small>kosongkan jika input baru</small>
													</div>
												</div>

												<div class="market-detail-control">
													<div class="market-detail-label">Item Name</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" ><input name="name" class="itemName" type="text"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Item Type</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" >
														<select name="type" class="itemType" >
															<?php while ( $row = mysqli_fetch_array($dataType)) { ?>
																<option value="<?php echo $row['type_id'] ?>"><?php echo $row['type_name'] ?></option>
															<?php } ?>
														</select>
													</div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Item Weight</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" ><input name="weight" class="itemWeight" type="text"></div>
												</div>
											</div>
											<div class="dashboard-detail-person">
												<div class="market-detail-control">
													<div class="market-detail-label">Item Price</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" ><input name="price" class="itemPrice"  type="text"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Item Barcode</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" ><input name="barcode" class="itemBarcode" type="text"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label">Item Image</div>
													<div class="market-detail-tick">:</div>
													<div class="market-detail-input" ><input name="image" class="" type="file"></div>
												</div>
												<div class="market-detail-control">
													<div class="market-detail-label"></div>
													<div class="market-detail-tick"></div>
													<div class="market-detail-input" ><input class="form-right" name="submitMaster" type="submit"></div>
												</div>
											</div>	
										</form>
										<div class="line"></div>
										<table class="table">
											<thead>
												<tr>
													<th>ID</th>
													<th>Name</th>
													<th>Type</th>
													<th>Weight</th>
													<th>Price</th>
													<th>Barcode</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody class="table-scroll">
												<?php while ($row = mysqli_fetch_array($dataItemMaster)) { ?>
												<tr>
													<td class="id-item-master"><?php echo $row['item_id'] ?></td>
													<td class="name-item-master"><?php echo $row['item_name'] ?></td>
													<td class="type-item-master"><?php echo $row['type_id'] ?></td>
													<td class="weight-item-master"><?php echo $row['item_weight'] ?></td>
													<td class="price-item-master"><?php echo $row['item_price'] ?></td>
													<td class="barcode-item-master"><?php echo $row['item_barcode'] ?></td>
													<td class=""><button class="edit-item-master">edit</button></td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>	
							</div>
						</div>



					</div>
				</div>
			</div>
		</div>
	</div>	
</body>
</html>