<?php 
defined('_BDZ') or die;

if (isset($_REQUEST['username']) && isset($_REQUEST['password'])) {
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];
	$queryLogin  = "SELECT * FROM xmart_user WHERE user_username = '$username' AND user_password = '$password'";
	$dataLogin = queryData($queryLogin);


	$response = array();
	$response["status"] = "success";
	$response["profile"] = array();

	$count = mysqli_num_rows($dataLogin);
	if ($count > 0) {
		$queryLogin = "SELECT 	a.user_username,
								a.user_password,
								b.user_id,
								b.address_street,
								b.address_no,
								b.address_rt,
								b.address_rw,
								b.address_additional,
								b.address_phone,
								b.address_longitude,
								b.address_latitude
						FROM 	xmart_user a 
								LEFT JOIN xmart_address b on a.user_id = b.user_id 
						WHERE 	a.user_username = '$username' and 
								a.user_password = '$password'";
		$datalogin = resultData($queryLogin);
		$login = array(
					'username' 	=> 			$datalogin["user_username"],
					'password' 	=> 			$datalogin["user_password"],
					'user_id' 	=> 			$datalogin["user_id"],
					'street' 	=> 			$datalogin["address_street"],
					'no' 		=> 			$datalogin["address_no"],
					'rt' 		=> 			$datalogin["address_rt"],
					'rw' 		=> 			$datalogin["address_rw"],
					'additional'=> 			$datalogin["address_additional"],
					'phone' 	=> 			$datalogin["address_phone"],
					'longitude' => 			$datalogin["address_longitude"],
					'latitude' 	=> 			$datalogin["address_latitude"]
					);
		$response['status']="success";


	}else{
			$login = array(
						'username' 	=> 			'',
						'password' 	=> 			'',
						'user_id' 	=> 			'',
						'street' 	=> 			'',
						'no' 		=> 			'',
						'rt' 		=> 			'',
						'rw' 		=> 			'',
						'additional'=> 			'',
						'phone' 	=> 			'',
						'longitude' => 			'',
						'latitude' 	=> 			''
						);
	$response['status']="fail";

	}
}else{
	$login = array(
					'username' 	=> 			'',
					'password' 	=> 			'',
					'user_id' 	=> 			'',
					'street' 	=> 			'',
					'no' 		=> 			'',
					'rt' 		=> 			'',
					'rw' 		=> 			'',
					'additional'=> 			'',
					'phone' 	=> 			'',
					'longitude' => 			'',
					'latitude' 	=> 			''
					);
	$response['status']="fail";

}
	array_push($response["profile"], $login);

echo json_encode($response);
 ?>