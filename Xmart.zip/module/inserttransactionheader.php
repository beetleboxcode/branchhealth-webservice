<?php 
defined('_BDZ') or die;


	$response = array();
	$response['status']="fail";

	if (isset($_REQUEST['transid']) && isset($_REQUEST['marketid']) && isset($_REQUEST['userid'])) {
		
		$transid = $_REQUEST['transid'];
		$marketid = $_REQUEST['marketid'];
		$userid = $_REQUEST['userid'];

		$querySales = "INSERT INTO xmart_sales(sales_id,market_id,sales_date,user_id,sales_status) VALUES ($transid,$marketid,now(),$userid,1)";
		$querySalesHistory = "INSERT INTO xmart_sales_history(sales_id,sales_status,sales_history_date) VALUES ($transid,1,now())";

		$executeSales = queryData($querySales);
		$executeSalesHistory = queryData($querySalesHistory);

		$response['status']="success";
	}

	echo json_encode($response);
 ?>