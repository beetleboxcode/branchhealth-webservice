<?php 
defined('_BDZ') or die;

	$response = array();
	$response['status']="fail";

	if (isset($_REQUEST['transid']) && isset($_REQUEST['itemid']) && isset($_REQUEST['count'])) {
		
		$transid = $_REQUEST['transid'];
		$itemid = $_REQUEST['itemid'];
		$count = $_REQUEST['count'];

		$querySalesdetail = "INSERT INTO xmart_sales_detail(sales_id,item_id,sales_detail_count) VALUES ($transid,$itemid,$count)";
		$executeSalesdetail = queryData($querySalesdetail);
		$response['status']="success";
	}

	echo json_encode($response);
 ?>