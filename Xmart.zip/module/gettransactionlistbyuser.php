<?php 
defined('_BDZ') or die;
	if (isset($_REQUEST['userid'])) {
		$userid = $_REQUEST['userid'];

		$response = array();
		$response["status"] = "fail";
		$response["transaction"] = array();

		$queryItem = "SELECT 
						a.sales_id,
						a.sales_date,
						case when a.sales_date_complete is null then '-' else a.sales_date_complete end as sales_date_complete,
						case when a.sales_status = 1 then 'pending' else 
							case when a.sales_status= 2 then 'sent' else 'complete'  end end as sales_status,
						d.market_name,
						c.address_street,
						c.address_additional,
						c.address_phone,
						c.address_longitude,
						c.address_latitude,
						case when e.notify_status='1' then '1' else '0' end notify_status
					FROM `xmart_sales` a 
							LEFT JOIN xmart_user b on a.user_id = b.user_id
							LEFT JOIN xmart_address c on b.user_id = c.user_id
							LEFT JOIN xmart_market d on a.market_id = d.market_id
							LEFT JOIN xmart_notify e on a.sales_id = e.sales_id
					where a.user_id =".$userid."
					 order by a.sales_date desc";
		$dataItem = queryData($queryItem);
		while ($row = mysqli_fetch_array($dataItem)) {
			$item = array(
					'id' 			=> 			$row["sales_id"],
					'date'			=> 			$row["sales_date"],
					'complete' 		=> 			$row["sales_date_complete"],
					'status' 		=> 			$row["sales_status"],
					'street' 		=> 			$row["address_street"],
					'additional' 	=> 			$row["address_additional"],
					'phone' 		=> 			$row["address_phone"],
					'longitude' 	=> 			$row["address_longitude"],
					'latitude' 		=> 			$row["address_latitude"],
					'name' 			=> 			$row["market_name"]
					);
			array_push($response['transaction'], $item);

			$response["status"] = "success";
		}
	}else{
			$item = array(
					'id' 			=> 			"",
					'date'			=> 			"",
					'complete' 		=> 			"",
					'status' 		=> 			"",
					'street' 		=> 			"",
					'additional' 	=> 			"",
					'phone' 		=> 			"",
					'longitude' 	=> 			"",
					'latitude' 		=> 			"",
					'name' 			=> 			""
					);
	array_push($response["transaction"], $item);
			
	}
	

echo json_encode($response);
 ?>