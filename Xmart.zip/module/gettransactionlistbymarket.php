<?php 
defined('_BDZ') or die;
	if (isset($_REQUEST['marketid'])) {
		$marketId = $_REQUEST['marketid'];

		$response = array();
		$response["status"] = "fail";
		$response["transaction"] = array();

		$queryItem = "SELECT 
						a.sales_id,
						a.sales_date,
						case when a.sales_date_complete is null then '-' else a.sales_date_complete end sales_date_complete,
						case when a.sales_status = 1 then 'pending' else 
							case when a.sales_status= 2 then 'sent' else 'complete'  end end as sales_status,
						c.address_street,
						c.address_additional,
						c.address_phone,
						c.address_longitude,
						c.address_latitude,
						b.user_username
					FROM `xmart_sales` a 
							left join xmart_user b on a.user_id = b.user_id
							left join xmart_address c on b.user_id = c.user_id 
					where a.market_id =".$marketId."
					Order by a.sales_date desc";
		$dataItem = queryData($queryItem);
		while ($row = mysqli_fetch_array($dataItem)) {
			$item = array(
					'id' 			=> 			$row["sales_id"],
					'date'			=> 			$row["sales_date"],
					'complete' 		=> 			$row["sales_date_complete"],
					'status' 		=> 			$row["sales_status"],
					'street' 		=> 			$row["address_street"],
					'additional' 	=> 			$row["address_additional"],
					'phone' 		=> 			$row["address_phone"],
					'longitude' 	=> 			$row["address_longitude"],
					'latitude' 		=> 			$row["address_latitude"],
					'name' 			=> 			$row["user_username"]
					);
			array_push($response['transaction'], $item);

			$response["status"] = "success";
		}
	}else{
			$item = array(
					'id' 			=> 			"",
					'date'			=> 			"",
					'complete' 		=> 			"",
					'status' 		=> 			"",
					'street' 		=> 			"",
					'additional' 	=> 			"",
					'phone' 		=> 			"",
					'longitude' 	=> 			"",
					'latitude' 		=> 			"",
					'name' 			=> 			""
					);
	array_push($response["transaction"], $item);
			
	}
	

echo json_encode($response);
 ?>