	<?php 
defined('_BDZ') or die;
	if (isset($_REQUEST['transcid'])) {
		$transcid = $_REQUEST['transcid'];

		$response = array();
		$response["status"] = "fail";
		$response["item"] = array();
		$response["idtrans"] = $transcid;
		$response["person"] = array();

		$queryItem = "SELECT 
					 		a.item_id,
					 		a.sales_detail_count,
					 		c.market_item_price,
					 		d.item_name
					 from xmart_sales_detail a
					 	LEFT JOIN xmart_sales b on a.sales_id = b.sales_id
					 	LEFT JOIN xmart_market_item c on a.item_id = c.market_item_id and b.market_id = c.market_id
					 	LEFT JOIN xmart_item d on c.item_id = d.item_id
					 where b.sales_id =".$transcid." 
					 Order by d.item_name";
		$dataItem = queryData($queryItem);
		while ($row = mysqli_fetch_array($dataItem)) {
			$item = array(
					'id' 			=> 			$row["item_id"],
					'count'			=> 			$row["sales_detail_count"],
					'market_price' 	=> 			$row["market_item_price"],
					'name' 			=> 			$row["item_name"]
					);
			array_push($response['item'], $item);

		}

		$queryPerson = "SELECT a.user_id,
								c.user_username,
								b.address_id,
								b.address_street,
								b.address_no,
								b.address_rt,
								b.address_rw,
								b.address_additional,
								b.address_phone,
								b.address_longitude,
								b.address_latitude,
								a.sales_date
						FROM xmart_sales a 
							LEFT JOIN xmart_address b on a.user_id = b.user_id
							LEFT JOIN xmart_user c on a.user_id = c.user_id
						WHERE a.sales_id=".$transcid;
		$dataPerson = queryData($queryPerson);
		while ($rowPerson = mysqli_fetch_array($dataPerson)) {
			$person = array(
						'user_id'				=>		$rowPerson["user_id"],
						'user_username'			=>		$rowPerson["user_username"],
						'address_id'			=>		$rowPerson["address_id"],
						'address_street'		=>		$rowPerson["address_street"],
						'address_no'			=>		$rowPerson["address_no"],
						'address_rt'			=>		$rowPerson["address_rt"],
						'address_rw'			=>		$rowPerson["address_rw"],
						'address_additional'	=>		$rowPerson["address_additional"],
						'address_phone'			=>		$rowPerson["address_phone"],
						'address_longitude'		=>		$rowPerson["address_longitude"],
						'address_latitude'		=>		$rowPerson["address_latitude"],
						'sales_date'			=>		$rowPerson["sales_date"]
						);
			array_push($response['person'], $person);
		}

		$response["status"] = "success";

	}else{
			$item = array(
					'id' 			=> 			"",
					'count'			=> 			"",
					'market_price' 	=> 			"",
					'name' 			=> 			""
					);
	array_push($response["item"], $item);
			
	}
	

echo json_encode($response);
 ?>

